<?php
/**
 * @package   WMPMana
 * @author    Antonio Trento https://antoniotrento.net
 * @copyright Copyright (C) 2007 - 2020 Antonio Trento
 * @license   Dual License: MIT or GNU/GPLv2 and later
 *
 * http://opensource.org/licenses/MIT
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Gantry Framework code that extends GPL code is considered GNU/GPLv2 and later
 */

namespace Gantry\Component\Router;

interface RouterInterface
{
    public function dispatch();
}
