<?php
/**
 * @package   Gantry5
 * @author    Antonio Trento https://antoniotrento.net
 * @copyright Copyright (C) 2007 - 2020 Antonio Trento
 * @license   MIT
 *
 * http://opensource.org/licenses/MIT
 */

namespace Gantry\WordPress\MultiLanguage;

interface MultiLantuageInterface
{
    /**
     * @return bool
     */
    public static function enabled();

    /**
     * @return string
     */
    public function getCurrentLanguage();

    /**
     * @return array
     */
    public function getLanguageOptions();
}
