<?php
/**
* @package   WMPMana
* @author    Antonio Trento https://antoniotrento.net
* @copyright Copyright (C) 2007 - 2020 Antonio Trento
* @license   GNU/GPLv2 and later
*
* http://www.gnu.org/licenses/gpl-2.0.html
*/

namespace Gantry\Framework;

/**
 * @deprecated 5.3.0
 */
class OutlineChooser extends Assignments {}
